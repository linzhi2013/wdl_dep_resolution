docker build -t swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-assembly_common:1.0 .
