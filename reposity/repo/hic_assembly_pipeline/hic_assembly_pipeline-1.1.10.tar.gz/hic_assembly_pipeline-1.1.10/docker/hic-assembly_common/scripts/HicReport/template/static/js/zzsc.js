$(function () {
    // $('img.image1').data('ad-desc', 'Whoa! This description is set through elm.data("ad-desc") instead of using the longdesc attribute.<br>And it contains <strong>H</strong>ow <strong>T</strong>o <strong>M</strong>eet <strong>L</strong>adies... <em>What?</em> That aint what HTML stands for? Man...');
    // $('img.image1').data('ad-title', 'Title through $.data');
    // $('img.image4').data('ad-desc', 'This image is wider than the wrapper, so it has been scaled down');
    // $('img.image5').data('ad-desc', 'This image is higher than the wrapper, so it has been scaled down');
    var galleries = $('.ad-gallery').adGallery();
    $('#switch-effect').change(
        function () {
            galleries[0].settings.effect = $(this).val();
            return false;
        }
    );
    $('#toggle-slideshow').click(
        function () {
            galleries[0].slideshow.toggle();
            return false;
        }
    );
    $('#toggle-description').click(
        function () {
            if (!galleries[0].settings.description_wrapper) {
                galleries[0].settings.description_wrapper = $('#descriptions');
            } else {
                galleries[0].settings.description_wrapper = false;
            }
            return false;
        }
    );


    getImgName();
    function getImgName() {
        var _list = $(".ad-gallery");
        //点击缩略图时
        _list.find('a').on('click', function () {
            var showName = $(this).find('img').attr('src');
            $(this).parents('.ad-gallery').prev().html(fillName(showName));
        });

        //点击大图左右按钮切换时
        _list.each(function () {
            //获取第一个图片的名字先提填写
            var src = $(this).find('a').first().attr('href');
            $(this).prev().html(fillName(src));
            $(this).find('a').last().addClass('last-img');
            $(this).find('a').first().addClass('first-img');
        });
        $(".ad-next-image").on("click", function () {
            $(this).parents('.ad-gallery').find("img").each(function () {
                if ($(this).css('opacity') == 1) { //找到点击之前下面缩略图显示的那张
                    if ($(this).parent().hasClass('last-img')) { //如果点击之前的是最后一张
                        $(this).parents('.ad-gallery').find('li').first().find("a").click();
                    } else {
                        $(this).parent().parent().next().find('a').click(); //它下面的那张，也就是要显示的那张
                    }
                }
            })
        });
        $(".ad-prev-image").on("click", function () {
            $(this).parents('.ad-gallery').find("img").each(function () {
                if ($(this).css('opacity') == 1) { //找到点击之前下面缩略图显示的那张
                    if ($(this).parent().hasClass('first-img')) { //如果点击之前的是第一张
                        $(this).parents('.ad-gallery').find('li').last().find("img").click();
                    } else {
                        $(this).parent().parent().prev().find('a').click(); //它下面的那张，也就是要显示的那张
                    }
                }
            })
        });
        /*填充名字*/
        function fillName(str) {
            if(!str){
                return;
            }
            var index_one = str.lastIndexOf('/'); //最后一个'/'的位置
            var index_two = str.lastIndexOf('.'); //最后一个'.'的位置
            str = str.substring(index_one + 1, index_two); //获得最后一个‘/’和最后一个'.'之间的字符串
            return str
        }
    }

});