#!/usr/bin/perl -w 
open IN1,$ARGV[0];
open IN2,$ARGV[1];
open OUT,">>$ARGV[2]";
$num_Valid_interaction_pairs=0;$num_Valid_interaction_pairs_FF=0;$num_Valid_interaction_pairs_RR=0;$num_Valid_interaction_pairs_RF=0;$num_Valid_interaction_pairs_FR=0;$num_Dangling_end_pairs=0;$num_Religation_pairs=0;$num_Self_Cycle_pairs=0;$num_Single_end_pairs=0;$num_Dumped_pairs=0;
while (<IN1>){
	chomp;
	$f=$_;
	open IT,$f;
	while (<IT>){
		@a=split /\t/,$_;
		#$Valid_interaction_pairs=$a[1] if (/Valid_interaction_pairs/);
		$Valid_interaction_pairs_FF=$a[1] if (/Valid_interaction_pairs_FF/);
		$Valid_interaction_pairs_RR=$a[1] if (/Valid_interaction_pairs_RR/);
		$Valid_interaction_pairs_RF=$a[1] if (/Valid_interaction_pairs_RF/);
		$Valid_interaction_pairs_FR=$a[1] if (/Valid_interaction_pairs_FR/);
		$Dangling_end_pairs=$a[1] if (/Dangling_end_pairs/);
		$Religation_pairs=$a[1] if (/Religation_pairs/);
		$Self_Cycle_pairs=$a[1] if (/Self_Cycle_pairs/);
		$Single_end_pairs=$a[1] if (/Single-end_pairs/);
		$Dumped_pairs=$a[1] if (/Dumped_pairs/);
	}
	#$num_Valid_interaction_pairs +=$Valid_interaction_pairs;
	$num_Valid_interaction_pairs_FF +=$Valid_interaction_pairs_FF;
	$num_Valid_interaction_pairs_RR +=$Valid_interaction_pairs_RR;
	$num_Valid_interaction_pairs_RF +=$Valid_interaction_pairs_RF;
	$num_Valid_interaction_pairs_FR +=$Valid_interaction_pairs_FR;
	$num_Dangling_end_pairs +=$Dangling_end_pairs;
	$num_Religation_pairs +=$Religation_pairs;
	$num_Self_Cycle_pairs +=$Self_Cycle_pairs;
	$num_Single_end_pairs +=$Single_end_pairs;
	$num_Dumped_pairs +=$Dumped_pairs;
}
$num_Valid_interaction_pairs = $num_Valid_interaction_pairs_FF + $num_Valid_interaction_pairs_RR + $num_Valid_interaction_pairs_RF + $num_Valid_interaction_pairs_FR;
#close IN1;
while (<IN2>){
	chomp;
	@y=split /\t/,$_;
	$total_uniq=$y[1] if (/Unique_paired_alignments/);
	$uniq=$y[2] if (/Unique_paired_alignments/);
	print OUT "$_\n";
}
$valid=$num_Valid_interaction_pairs/$total_uniq*100;
$valid=sprintf ("%.2f",$valid);
$youxiaoshuju=$valid*$uniq/100;
$youxiaoshuju=sprintf ("%.2f",$youxiaoshuju);

print OUT "Valid_interaction_pairs\t$num_Valid_interaction_pairs\nValid_interaction_pairs_FF\t$num_Valid_interaction_pairs_FF\nValid_interaction_pairs_RR\t$num_Valid_interaction_pairs_RR\nValid_interaction_pairs_RF\t$num_Valid_interaction_pairs_RF\nValid_interaction_pairs_FR\t$num_Valid_interaction_pairs_FR\n Dangling_end_pairs\t$num_Dangling_end_pairs\nReligation_pairs\t$num_Religation_pairs\nSelf_Cycle_pairs\t$num_Self_Cycle_pairs\nSingle_end_pairs\t$num_Single_end_pairs\nDumped_pairs\t$num_Dumped_pairs\n\nValid_interaction_pairs_rate\t$valid\nvailded_reads_of_unique_mapping\t$youxiaoshuju\n";


#print OUT "Total_pairs_processed\t$num_Total_pairs\t$to\nUnmapped_pairs\t$num_Unmapped\t$unm\nLow_qual_pairs\t$num_Low_qual\t$low\nUnique_paired_alignments\t$num_Unique_paired\t$uniq\nMultiple_pairs_alignments\t$num_Multiple_pairs\t$mul\nPairs_with_singleton\t$num_Pairs_with_singleton\t$sin\nLow_qual_singleton\t$num_Low_qual_singleton\t$sin_low\nUnique_singleton_alignments\t$num_Unique_singleton_alignments\t$sin_uniq\nMultiple_singleton_alignments\t$num_Multiple_singleton_alignments\t$sin_mul\nReported_pairs\t$num_Reported_pairs\t$rep\n"
