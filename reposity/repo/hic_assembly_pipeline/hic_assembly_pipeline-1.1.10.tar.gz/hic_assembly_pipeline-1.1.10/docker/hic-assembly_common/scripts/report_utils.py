"report useful functions"

import os
import glob
import shutil
import ConfigParser

def safecopy(file, path):
    "copy file to path"
    if not os.path.exists(file):
        raise Exception("ERROR! file not found: %s" % file)
    if not os.path.exists(path):
        os.makedirs(path)
    shutil.copy(file, path)


def loopcopy(pattern, path):
    '''
    pattern: shell regex pattern, "*.txt"
    path:    destination dir
    '''
    files = glob.glob(pattern)
    if files:
        for fig in glob.glob(pattern):
            safecopy(fig, path)
    else:
        raise Exception("ERROR! file not found: %s" % pattern)


def readtbl(table, only5=False):
    "display xls table"
    content = []
    if not os.path.exists(table):
        raise Exception("ERROR! file not found: %s" % table)
    handle = open(table)
    handle.readline()
    if only5:
        for i in range(5):
            line = handle.readline()
            if line != "":
                content.append(line.strip().split('\t'))
    else:
        for line in handle:
            content.append(line.strip().split('\t'))
    handle.close()
    return content


def schfile(path, pattern="*.png"):
    "return file list"
    if not os.path.exists(path):
        raise Exception("ERROR! path not found: %s" % path)
    return [os.path.basename(fig) for fig in glob.glob(os.path.join(path, pattern))]


def parse_cfg(cfg):
    "parse cfg file , return dict"
    if not os.path.exists(cfg):
        raise Exception("ERROR! config file not found: %s" % cfg)
    conf = ConfigParser.ConfigParser()
    conf.read(cfg)
    r = dict(conf.items('basic'))
    return r

