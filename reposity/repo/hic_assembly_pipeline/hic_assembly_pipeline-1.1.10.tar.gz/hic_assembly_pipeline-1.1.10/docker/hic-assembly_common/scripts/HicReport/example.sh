/export/software/Base/python/Python/Python-2.7.13/bin/python Hic_report.py -id ./06Report/ -od test_out -cn WHWLZ-2019030101A -pn 田鳖 -wt 谭云涛 -rv 朱明飞 -sf 
