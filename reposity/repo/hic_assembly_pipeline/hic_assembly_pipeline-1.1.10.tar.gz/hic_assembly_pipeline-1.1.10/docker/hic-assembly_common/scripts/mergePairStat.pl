#!/usr/bin/perl -w 
open IN1,$ARGV[0];
open OUT,">$ARGV[1]";
$num_Total_pairs=0;$num_Unmapped=0;$num_Low_qual=0;$num_Unique_paired=0;$num_Multiple_pairs=0;$num_Pairs_with_singleton=0;$num_Low_qual_singleton=0;$num_Unique_singleton_alignments=0;$num_Multiple_singleton_alignments=0;$num_Reported_pairs=0;
while (<IN1>){
	chomp;
	$f=$_;
	open IT,$f;
	while (<IT>){
		@a=split /\t/,$_;
		$Total_pairs=$a[1] if (/Total_pairs/);
		$Unmapped=$a[1] if (/Unmapped_pairs/);
		$Low_qual=$a[1] if (/Low_qual_pairs/);
		$Unique_paired=$a[1] if (/Unique_paired_alignments/);
		$Multiple_pairs=$a[1] if (/Multiple_pairs_alignments/);
		$Pairs_with_singleton=$a[1] if (/Pairs_with_singleton/);
		$Low_qual_singleton=$a[1] if (/Low_qual_singleton/);
		$Unique_singleton_alignments=$a[1] if (/Unique_singleton_alignments/);
		$Multiple_singleton_alignments=$a[1] if (/Multiple_singleton_alignments/);
		$Reported_pairs=$a[1] if (/Reported_pairs/);
	}
	$num_Total_pairs +=$Total_pairs;
	$num_Unmapped +=$Unmapped;
	$num_Low_qual +=$Low_qual;
	$num_Unique_paired +=$Unique_paired;
	$num_Multiple_pairs +=$Multiple_pairs;
	$num_Pairs_with_singleton +=$Pairs_with_singleton;
	$num_Low_qual_singleton +=$Low_qual_singleton;
	$num_Unique_singleton_alignments +=$Unique_singleton_alignments;
	$num_Multiple_singleton_alignments +=$Multiple_singleton_alignments;
	$num_Reported_pairs +=$Reported_pairs;
}
$to=$num_Total_pairs/$num_Total_pairs;
#$to=~s/\.[0-9]{4}//;
$to *=100;
$to =&FF($to);

$unm=$num_Unmapped/$num_Total_pairs;
#$unm=~s/([0-9]+\.[0-9]{2})[0-9]+/$1/;
$unm *=100;
$unm =&FF($unm);

$low=$num_Low_qual/$num_Total_pairs;
#$low=~s/([0-9]+\.[0-9]{2})[0-9]+/$1/;
$low *=100;
$low =&FF($low);

$uniq=$num_Unique_paired/$num_Total_pairs;
#$uniq=~s/([0-9]+\.[0-9]{2})[0-9]+/$1/;
$uniq *=100;
$uniq =&FF($uniq);

$mul=$num_Multiple_pairs/$num_Total_pairs;
#$mul=~s/\.[0-9]{4}//;
$mul *=100;
$mul =&FF($mul);

$sin=$num_Pairs_with_singleton/$num_Total_pairs;
#$sin=~s/\.[0-9]{4}//;
$sin *=100;
$sin =&FF($sin);

$sin_low=$num_Low_qual_singleton/$num_Total_pairs;
#$sin_low=~s/\.[0-9]{4}//;
$sin_low *=100;
$sin_low =&FF($sin_low);

$sin_uniq=$num_Unique_singleton_alignments/$num_Total_pairs;
#$sin_uniq=~s/\.[0-9]{4}//;
$sin_uniq *=100;
$sin_uniq =&FF($sin_uniq);

$sin_mul=$num_Multiple_singleton_alignments/$num_Total_pairs;
#$sin_mul=~s/\.[0-9]{4}//;
$sin_mul *=100;
$sin_mul =&FF($sin_mul);

$rep=$num_Reported_pairs/$num_Total_pairs;
#$rep=~s/\.[0-9]{4}//;
$rep *=100;
$rep =&FF($rep);

print OUT "Total_pairs_processed\t$num_Total_pairs\t$to\nUnmapped_pairs\t$num_Unmapped\t$unm\nLow_qual_pairs\t$num_Low_qual\t$low\nUnique_paired_alignments\t$num_Unique_paired\t$uniq\nMultiple_pairs_alignments\t$num_Multiple_pairs\t$mul\nPairs_with_singleton\t$num_Pairs_with_singleton\t$sin\nLow_qual_singleton\t$num_Low_qual_singleton\t$sin_low\nUnique_singleton_alignments\t$num_Unique_singleton_alignments\t$sin_uniq\nMultiple_singleton_alignments\t$num_Multiple_singleton_alignments\t$sin_mul\nReported_pairs\t$num_Reported_pairs\t$rep\n";

#sub Fds(){
#	$fq = $_[0];
#	$ff = sprintf (".2f",$fq);
#	return ($ff);
#}
####################
sub FF(){
	$ef = $_[0];
	$ee = sprintf ("%.2f",$ef);
	return ($ee);
}
