docker build -t "swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-pro:2.11.1" .
