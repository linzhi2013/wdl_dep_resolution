============================================================
QuickStart
============================================================


This pipeline was adapted based on ``/export/personal1/duanxk/script/process_lachesis/Lachesis_pipeline_v2`` (NextOmics wuhan-master2 cluster)

Source files
=============
Suppose your source file of Hi-C Assembly pipeline is in
``/path/to/Hi-C_Assembly_pipeline/``.



Run test
=========================

First, create a test directory::

    $ mkdir -p /path/to/my_test/LibraryQC
    $ cd /path/to/my_test/LibraryQC

Second, find out the test data paths::

    $ ls -lhrt /path/to/C_Assembly_pipeline/test/LibraryQC/data/
    total 467M
    -rw-r--r-- 3 menggl company  35M Oct 21 16:09 BP2.fasta
    -rw-r--r-- 1 menggl company  112 Oct 22 14:03 lib_info.xls
    -rw-r--r-- 2 menggl company 210M Oct 21 16:09 test.BP2.1.fq.gz
    -rw-r--r-- 2 menggl company 224M Oct 21 16:09 test.BP2.2.fq.gz


Next, we need an configure file to specify parameter values.
You can create the ``input.json`` file by yourself::

    $ cd /path/to/Hi-C_Assembly_pipeline/
    $ java -jar /path/to/womtool-42.jar inputs Hi-C_Assembly_pipeline/src/wdl/LibraryQC/Workflow/LibraryQC.wdl > /path/to/my_test/LibraryQC/inupt.json
    $ cd /path/to/my_test/LibraryQC/

.. warning::

    You must be in the ``/path/to/Hi-C_Assembly_pipeline/`` directory
    when generating a ``input.json`` file.

**Or you can copy the ready-to-use configure file**: ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_basic.json`` and ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_advanced.json``.

In this tutorial, we use ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_basic.json`` directly, so now copy it to the test directory (``/path/to/my_test/LibraryQC``)::

    $ cp /path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_basic.json ./


The content of ``input_basic.json`` file::

    {
    "LibraryQC.contract_number": "String",
    "LibraryQC.cutsite": "GATCGATC",
    "LibraryQC.genome_fasta_file": "File",
    "LibraryQC.fq1": "File",
    "LibraryQC.fq2": "File",
    "LibraryQC.job_thread": "4",
    "LibraryQC.lib_info_xls": "File",
    "LibraryQC.min_map_qual": "0",
    "LibraryQC.phred64": "Boolean? (optional)",
    "LibraryQC.project_name": "String",
    "LibraryQC.report_dir": "String",
    "LibraryQC.restriction_sites": "dpnii",
    "LibraryQC.reviewer": "String",
    "LibraryQC.root": "/export/",
    "LibraryQC.species_name": "String",
    "LibraryQC.workdir_base": "String",
    "LibraryQC.writer": "String"
    }



Now edit the ``input_basic.json`` file to be::

    {
    "LibraryQC.contract_number": "10086",
    "LibraryQC.cutsite": "GATCGATC",
    "LibraryQC.genome_fasta_file": "/path/to/C_Assembly_pipeline/test/LibraryQC/data/BP2.fasta",
    "LibraryQC.fq1": "/path/to/C_Assembly_pipeline/test/LibraryQC/data//test.BP2.1.fq.gz",
    "LibraryQC.fq2": "/path/to/C_Assembly_pipeline/test/LibraryQC/data/test.BP2.2.fq.gz",
    "LibraryQC.job_thread": "4",
    "LibraryQC.lib_info_xls": "/path/to/C_Assembly_pipeline/test/LibraryQC/data/lib_info.xls",
    "LibraryQC.min_map_qual": "0",
    "LibraryQC.phred64": "false",
    "LibraryQC.project_name": "1KITE",
    "LibraryQC.report_dir": "1KITE_HiC_report",
    "LibraryQC.restriction_sites": "dpnii",
    "LibraryQC.reviewer": "Guanliang Meng",
    "LibraryQC.root": "/export/",
    "LibraryQC.species_name": "Insect",
    "LibraryQC.workdir_base": "/path/to/my_test/LibraryQC/result/",
    "LibraryQC.writer": "Guanliang Meng"
    }


The major options you should care about::

      "LibraryQC.genome_fasta_file": "File",
      "LibraryQC.fq1": "File",
      "LibraryQC.fq2": "File",
      "LibraryQC.job_thread": "4",
      "LibraryQC.lib_info_xls": "File",
      "LibraryQC.phred64": "false",


.. warning::
    The ``LibraryQC.root`` is the disk name where all you data (for this analysis) are.


.. note::

  Two ready-to-use ``input_basic.json`` and ``input_advanced.json`` files have
  also been provided in ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_basic.json`` and ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_advanced.json``, along the run script file ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/run_example.sh``.

.. tip::

    To have more control over the pipeline, you can use the ``/path/to/Hi-C_Assembly_pipeline/config/LibraryQC/input_advanced.json``.



Then run the pipeline::

    $ pathdir='/path/to/Hi-C_Assembly_pipeline'
    $ java -Dsystem.job-shell=/bin/sh \
    -Dconfig.file=${pathdir}/docker/localhost.normal-user.docker.config \
    -jar /path/to/cromwell-42.jar run \
    -p ${pathdir}/src.zip \
    ${pathdir}/src/wdl/LibraryQC/Workflow/LibraryQC.wdl \
    -i input_basic.json


.. warning::

    The ``-p ${pathdir}/src.zip`` option is very important.
    Cromwell will find the dependencies from this zip file for the workflow you are running.


Results
===================

In the terminal::

  $ ls -lhrt /path/to/my_test/LibraryQC/result/

  drwxr-xr-x 2 root root 4.0K Oct 22 15:40 01_QC/
  drwxr-xr-x 2 root root 4.0K Oct 22 15:43 midfile/
  drwxr-xr-x 5 root root 4.0K Oct 22 16:13 02_MAP/
  drwxr-xr-x 4 root root 4.0K Oct 22 16:21 03_HiC_QC_report/


The report file is in the ``03_HiC_QC_report/`` directory.

