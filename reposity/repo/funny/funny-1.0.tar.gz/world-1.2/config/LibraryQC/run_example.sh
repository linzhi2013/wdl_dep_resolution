pathdir='/export/personal/menggl/dev/Hi-C_Assembly_pipeline'
java -Dsystem.job-shell=/bin/sh \
-Dconfig.file=${pathdir}/docker/localhost.normal-user.docker.config \
-jar /export/personal/menggl/soft/cromwell-42/cromwell-42.jar run \
-p ${pathdir}/src.zip \
${pathdir}/src/wdl/LibraryQC/Workflow/LibraryQC.wdl \
-i input.json

