#!/usr/bin/env python
# -*- coding:utf-8 -*-
"Nextomics Hi-c report"

from __future__ import division
import os
import sys
import glob
import shutil
import jinja2
import logging
import argparse
from time import localtime
from docxtpl import DocxTemplate
import json
__AUTHOR__ = "tanyt@grandomics.com"
__VERSION__ = "v1.1_20190730"

reload(sys)
sys.setdefaultencoding('utf-8')
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.dirname(BASE_DIR))
from report_utils import safecopy,readtbl,schfile,loopcopy
logging.basicConfig(level=logging.DEBUG, format="[%(levelname)s] %(asctime)s: %(message)s")
logger = logging.getLogger('NextOmics Hi-c Report')
SAMPLE_NAME="sample01"
def str2num(ele):
    try:
        if '.' in ele:
            num = float(ele)
        else:
            num=int(ele)
    except ValueError:
        return ele
    return num
def formatnum(num):
#    assert type(ele) is int or type(ele) is float
    if type(num) is int:
        return '{:,}'.format(num)
    elif type(num) is float:
        return '{:.2f}'.format(num)
    else:
        return num

def autoformat(line):
    '''format a array, is element is int use {:,}, is float use {:.2f}'''
    assert type(line) is list,"input must be list"
    newline = []
    for ele in line:
        if type(ele) is str:
            ele=str2num(ele)
            newline.append(formatnum(ele))
        else:
            newline.append(formatnum(ele))
    return newline
def array2tbl(array,tbl):
    '''fomat 2d-array's number to xls'''
    newarray = []
    with open(tbl,'w') as tblout:
        for line in array:
            newline = autoformat(line)
            tblout.write("\t".join(newline) + "\n")
            newarray.append(newline)
    return newarray

def getTab2(jfile,ofile):
    '''from fastp get Tab2_QC_filter.xls'''
    jf=open(jfile,'r')
    QC=json.loads(jf.read())
    array = []
    global SAMPLE_NAME
    head = ["Sample",SAMPLE_NAME]
    line2 = ["Raw Paired-end Reads",QC["summary"]["before_filtering"]["total_reads"]]
    line3 = ["Clean Paired-end Reads",QC["summary"]["after_filtering"]["total_reads"]]
    line4 = ["Clean Bases(bp)",QC["summary"]["after_filtering"]["total_bases"]]
    line5 = ["Clean Paired-end Reads Rate (%)",line3[1]/line2[1]*100]
    line6 = ["Clean Q30 Bases Rate (%)",QC["summary"]["after_filtering"]["q30_rate"]*100]
    array = [head,line2,line3,line4,line5,line6]
    array=array2tbl(array,ofile)
    array = array[1:]
    return array
def readspecline(query,infile):
    """read specific lines from hicpro.result"""
    seen = []
    data = {}
    with open(infile,'r') as hc:
        for line in hc:
            line=line.strip()
            ele = line.split("\t")
            if ele[0] in query:
                data[ele[0]]=ele[1:]
                seen.append(ele[0])
            if seen.sort() == query:
                break
    return data

def getTab4(hicpro,ofile):
    query=["Total_pairs_processed",
            "Unmapped_pairs",
            "Pairs_with_singleton",
            "Multiple_pairs_alignments",
            "Reported_pairs"]
    query_unsort = query
    query=sorted(query)
    tableFirst = ["Clean Paired-end Reads",
                "Unmapped Paired-end Reads",
                "Paired-end Reads with Singleton",
                "Multi Mapped Paired-end Reads",
                "Unique Mapped Paired-end Reads"]
    ratio = ["Clean_ratio","Unmapped Paired-end Reads Rate (%)",
            "Paired-end Reads with Singleton Rate (%)","Multi Mapped Ratio (%)",
            "Unique Mapped Ratio (%)"]
    allFirst = ["Clean Paired-end Reads",
                "Unmapped Paired-end Reads",
                "Unmapped Paired-end Reads Rate (%)",
                "Paired-end Reads with Singleton",
                "Paired-end Reads with Singleton Rate (%)",
                "Multi Mapped Paired-end Reads",
                "Multi Mapped Ratio (%)",
                "Unique Mapped Paired-end Reads",
                "Unique Mapped Ratio (%)"]

    data=readspecline(query,hicpro)
    global SAMPLE_NAME
    head = ["Sample",SAMPLE_NAME]
    array = [head]
    alldata = {}
    for q,tb,rto in zip(query_unsort,tableFirst,ratio):
        alldata[tb] = int(data[q][0])
        alldata[rto] = float(data[q][1])
    for first  in allFirst:
        array.append([first,alldata[first]])
    array=array2tbl(array,ofile)
    array = array[1:]
    return(array)

def getTab5(hicpro,ofile):
    query=["Total_pairs_processed",
            "Reported_pairs","Unique_paired_alignments",
            "Dangling_end_pairs",
            "Self_Cycle_pairs",
            "Dumped_pairs",
            "Valid_interaction_pairs",
            "Unique_paired_alignments",
            ]
    data=readspecline(query,hicpro)
    global SAMPLE_NAME
    head = ["Sample",SAMPLE_NAME]
    array2 = [ head,
    ["Unique Mapped Paired-end Reads",int(data["Unique_paired_alignments"][0])],
    ["Dangling End Paired-end Reads",int(data["Dangling_end_pairs"][0])],
    ["Self Circle Paired-end Reads",int(data["Self_Cycle_pairs"][0])],
    ["Dumped Paired-end Reads",int(data["Dumped_pairs"][0])],
    ["Valid Paired-end Reads",int(data["Valid_interaction_pairs"][0])],
    ["Valid Rate (%)",float(int(data["Valid_interaction_pairs"][0])/int(data["Unique_paired_alignments"][0]))*100],
    ["Vailded reads of unique mapping(%)",float(int(data["Valid_interaction_pairs"][0])/int(data["Total_pairs_processed"][0]))*100]
    ]
    array2=array2tbl(array2,ofile)
    array2 = array2[1:]
    return array2
    
    
def getTab6(clsreport,ofile):
    """get Tab6 from ClusterReport.txt"""
    other = {}
    with open(clsreport,'r') as cs:
        for line in cs:
            if "Total length:" in line:
                total_len=int(line.split("Total length:")[1].split()[0])
            if "Number of contigs in clusters:" in line:
                cluster_cut_bins = int(line.split("Number of contigs in clusters:")[1].split()[0])
            if "Length of contigs in clusters:" in line:
                clustered_contig_len = int(line.split("Length of contigs in clusters:")[1].split()[0])
                clustered_contig_len_ratio = float(line.split("Length of contigs in clusters:")[1].split()[1].lstrip("(").rstrip("%"))
            if "N contigs:" in line:
                n_bins = int(line.split("N contigs:")[1].split()[0])
            if line.startswith("CLUSTER_N ="):
                n_cluster = line.split("=")[1].strip()
    other["cluster_bin_ratio"] = formatnum(cluster_cut_bins/n_bins*100)
    other["cluster_len_ratio"] = clustered_contig_len_ratio
    other["cluster_cut_bins"] = formatnum(int(cluster_cut_bins))
    other["n_cluster"] = n_cluster
    global SAMPLE_NAME
    head = ["Sample",SAMPLE_NAME]
    array = [head,
    ["草图Contig切bin总数",n_bins],
    ["草图Contig总长(bp)",total_len],
    ["聚类Contig切bin个数",cluster_cut_bins],
    ["聚类Contig长度(bp)",clustered_contig_len],
    ["聚类Contig长度比例(%)",clustered_contig_len_ratio]]
    array=array2tbl(array,ofile)
    array=array[1:]
    return array,other

def getTab7(chrreport,ofile):
    """input Report.xls, output Tab7 and array, and other"""
    head = ["Chr","Length","Scaf Num"]
    array = [head]
    other = {}
    with open(chrreport,'r') as  cr:
        cr.readline()
        for line in cr:
            line=line.strip()
            if not line.startswith("#"):
                array.append(line.strip().split())
            if line.startswith("Total"):
                other["chr_genome_size"] = line.strip().split()[1]
            if "Orangin Genome Size" in line:
                org_genome_size=int(line.split(":")[1].strip())
                other['org_genome_size']=org_genome_size
            if "Loading Rate" in line:
                loading_ratio = float(line.split()[3])
                other['loading_ratio']=formatnum(loading_ratio*100)
    array=array2tbl(array,ofile)
    array = array[1:]
    return array,other

def copyfigs(project_dir, report_dir):
    if os.path.exists(report_dir):
        shutil.rmtree(report_dir)
    shutil.copytree(os.path.join(BASE_DIR, "template"), report_dir)
    imgdir = os.path.join(report_dir, "static", "media")

def bp2Mb(bp):
    return "{:.2f}".format(int(bp)/1000000)


def readtbls(project_dir,Tabsdir):
    d = {}
    safecopy("%s/lib_info.xls" % project_dir,Tabsdir)
    d['lib_info'] = readtbl("%s/lib_info.xls" % project_dir)
    d['Tab2_QC_filter']=getTab2("%s/%s.QC.json" % (project_dir,SAMPLE_NAME),"%s/Tab2_QC_filter.xls" % Tabsdir)
    d["Tab4_sample_aln"]=getTab4("%s/hicpro.result" % project_dir,"%s/Tab4_sample_aln.xls" % Tabsdir)
    d["unique_mapped_reads"] = d["Tab4_sample_aln"][7][1] 
    d["unique_mapped_ratio"] = d["Tab4_sample_aln"][8][1]
    Tab5info = getTab5("%s/hicpro.result" % project_dir,"%s/Tab5_valid.xls" % Tabsdir)
    d["Tab5_valid"]=Tab5info
    d["Valid_Interaction_Pairs"] = d["Tab5_valid"][4][1]
    d["valid_ratio"] = d["Tab5_valid"][5][1]
    d["valid_reads_of_unique_mapping"]=d["Tab5_valid"][6][1]
    return d

def main():
    parser = argparse.ArgumentParser(description='''
        create HTML report for Hic QC pipeline.
        RESULT DIR must contain, filename must be the same, except *.QC.json:
            ├── hicpro.result -> ../02_MAP/validPairs/hicpro.result
            ├── SAMPLENAME.QC.json #SAMPLENAME是变量，会被读取作为表格中的Sample表头。
            ├── lib_info.xls #自己填写
        ''',
        formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-id', '--result_dir', help="""input hic result dir, 
                    which must contain files like RESULT DIR""", 
                        required=True)
    parser.add_argument('-od', '--report_dir', help="output report dir", default="./")
    parser.add_argument('-cn', '--contract', help="contract number", required=True)
    parser.add_argument('-pn', '--name', help="project name", required=True)
    parser.add_argument('-wt',"--writer",help="writer name",required=True)
    parser.add_argument('-rv',"--reviewer",help="reviewer name",required=True)
    args = parser.parse_args()
    logger.info("Hic report start:")
    logger.info("1. copy files...")
    report_dir = os.path.join(args.report_dir, "%s_Hic_QC_Report" % args.contract)
    img_dir = os.path.join(report_dir, "static", "report_image")
    copyfigs(args.result_dir, report_dir)
    Tabsdir = os.path.join(report_dir,"Tabs")
    if not os.path.exists(Tabsdir):
        os.mkdir(Tabsdir)
    logger.info("2. readtbls...")
    global SAMPLE_NAME
    SAMPLE_NAME = os.path.basename(glob.glob("%s/*.QC.json" % args.result_dir)[0])[:-8]
    rnd = readtbls(args.result_dir,Tabsdir)
    rnd["sample_name"] = SAMPLE_NAME 
    rnd["project_name"] = args.name
    rnd["project_number"] = args.contract
    rnd['reviewer'] = args.reviewer
    rnd['writer'] = args.writer
    rnd["report_time"] = "%s年%s月%s日" % (localtime()[0], localtime()[1],localtime()[2])
    logger.info("3. generate html report...")
    tpl = jinja2.Template(open(os.path.join(BASE_DIR, "mainQC.html")).read())
    with open(os.path.join(report_dir, "mainQC.html"), 'w') as out:
        out.write(tpl.render(rnd))
    logger.info("3. generate docx report...")

    docx_path=os.path.join(BASE_DIR,"QC_template.docx")
    doc = DocxTemplate(docx_path)
    doc.render(rnd)
    doc.save("%s/%s_Hic_QC_Report.docx" % (report_dir, args.contract))
    logger.info("packaging reports...")
    os.chdir(args.report_dir)
    os.system("zip -r %s_Hic_QC_Report.zip %s_Hic_QC_Report" % (args.contract,args.contract))
    logger.info("done")
if __name__ == "__main__":
    main()
