//figure_data

new Vue({
  el:'#app',
  data: {
    baseUrl: 'static/report_image/',
    figure_data: figure_data,
    table_data: table_data,
	render_data: render_data
  }

})