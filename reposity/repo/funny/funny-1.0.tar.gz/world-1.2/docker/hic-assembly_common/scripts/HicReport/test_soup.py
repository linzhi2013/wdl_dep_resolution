#!/usr/bin/env python2
#coding: utf-8

from BeautifulSoup import BeautifulSoup
f=open('main.html','r')
soup = BeautifulSoup(f)

def h4_has_id(tag):
    return tag.name == "h4" and tag.has_atrr('id')
for tag in soup.findAll("h4"):
    print(tag)
    
print(soup.findAll(h4_has_id))
