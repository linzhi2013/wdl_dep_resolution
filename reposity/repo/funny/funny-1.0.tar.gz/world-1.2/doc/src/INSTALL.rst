=======================
Installation
=======================



Prerequisites
=================
1. A Unix-based operating system (yes, that includes Mac!)

2. A Java 8 runtime environment.

    You can see what you have by running ``$ java -version`` on a terminal. You're looking for a version that's at least 1.8 or higher.
    If not, you can download Java `here <http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html>`__.

3. `Docker <https://www.docker.com/>`__ installed.

    All dependencies are wrapped in docker Docker images. You must have
    the privilege to run Docker containers.



Cromwell installation
======================

Download the packages https://github.com/broadinstitute/cromwell/releases/download/42/cromwell-42.jar and https://github.com/broadinstitute/cromwell/releases/download/42/womtool-42.jar .

Remember the paths to these two files on your computer, for example::

    /path/to/cromwell-42.jar
    /path/to/womtool-42.jar

There is no need to installation.



Source files
=============
You may download the Hi-C_Assembly_pipeline source files from
http://gitlab.grandomics.com/Guanliang_Meng/hi-c_assembly_pipeline.git,
or get a copy from master2 cluster
``/export/personal/menggl/dev/Hi-C_Assembly_pipeline/``.

Suppose now your source file is in
``/path/to/Hi-C_Assembly_pipeline/``.


Building Docker images
========================

All the dependencies are wrapped in Docker images, so you must build the Docker
images firstly::

    $ cd /path/to/Hi-C_Assembly_pipeline
    $ ls -lhrt

You get::

        -rw-r--r-- 1 menggl company  536 Oct 21 16:09 LICENSE
        drwxr-xr-x 3 menggl company 4.0K Oct 21 16:09 src/
        drwxr-xr-x 3 menggl company 4.0K Oct 22 09:56 config/
        drwxr-xr-x 4 menggl company 4.0K Oct 22 11:26 docker/
        -rw-r--r-- 1 menggl company  218 Oct 22 11:52 README.md
        -rw-r--r-- 1 menggl company  25K Oct 22 12:58 src.zip
        drwxr-xr-x 4 menggl company 4.0K Oct 22 14:03 test/
        drwxr-xr-x 6 menggl company 4.0K Oct 22 14:20 doc/



Now type::

    $ ls -lhrt docker/*/build.sh

You will see something like::

        -rwxr-xr-x 1 menggl company 81 Oct 21 16:09 docker/hic-pro/build.sh
        -rwxr-xr-x 1 menggl company 88 Oct 21 16:09 docker/hic-assembly_common/build.sh

Now, change into the directory where each ``build.sh`` file is, and build the
docker images, for example::

    cd docker/hic-pro
    sh build.sh

.. important::
    You MUST run ALL the ``build.sh`` files (with the ``sh`` command) ,
    not just the ``docker/hic-pro/build.sh``!

This can take quite long time, depending on your network speed!

.. tip::
    You can open mutiple windows and run different ``build.sh`` files at the same time.


When all images have been built (and pulled) successfully, run::

     $ docker images
        REPOSITORY                                                          TAG                 IMAGE ID            CREATED             SIZE
        swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-assembly_common   1.0                 6c24ad8ef401        23 hours ago        867MB
        swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-pro               2.11.1              480ffe30953e        3 days ago          1.69GB

Your result should be similar to the above.



Push images to Huawei Cloud
=================================

The Docker images built in the above can be used for localhost run.
However, if you want to deploy this pipeline to Huawei Cloud,
you have to push these Docker images to the repository of Huawei Cloud.

For NextOmics, the Huawei Cloud's repository is ``swr.cn-north-1.myhuaweicloud.com/nextomics-wh``,
which means that you must ensure your image's tag must start with ``swr.cn-north-1.myhuaweicloud.com/nextomics-wh``.

For example, if you have a Docker image whose tag is ``hic-assembly_common:1.0``, then you should do::

    $ docker tag hic-assembly_common:1.0 swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-assembly_common:1.0

Since the images built in the above already have correct tag format, you do not need to ``tag`` again.


To push your Docker images to Huawei Cloud's repository, you
should ask you administrator to give you an account and password,
and then login it. For example::

    $ docker login -u cn-north-1@2TOY0HJR5MPZHFDEFM0J -p ab72aafb2f2c229027b67ff63b7bb413a5ee94e38b3441c0564ff26500afee58 swr.cn-north-1.myhuaweicloud.com

Then push your Docker image to Huawei Cloud one by one::

    $ docker push swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-assembly_common:1.0
    $ docker push swr.cn-north-1.myhuaweicloud.com/nextomics-wh/hic-pro:2.11.1


Prepare the imports files
=================================
In order for Cromwell to know the paths to the task scripts,
it is necessary to point to the scripts when executing the entire
workflow and this is done by zipping the source code::

    $ cd /path/to/Hi-C_Assembly_pipeline/
    $ zip -r src.zip src/

.. tip::

    If you have updated the files in ``src/``, you must also recreate the ``src.zip`` file.



Documention instructions
========================

1. All ``Main*-workflow`` and ``sub-workflow`` can be run independently.
All you have to do is, firstly generate a ``input.json``::

    $ cd /path/to/Hi-C_Assembly_pipeline
    $ java -jar /path/to/womtool-42.jar inputs src/wdl/path/to/this_workflow > input.json

.. warning::

    You must be in the directory ``/path/to/Hi-C_Assembly_pipeline``
    when generating a ``input.json`` file, however, you can redirect the output into
    somewhere you want it to go, or you can move the above ``input.json`` to your project directory.
    This is due to the limitation of the ``womtool`` package,
    which cannot find relative task scripts if you are not in the directory ``/path/to/Hi-C_Assembly_pipeline``.

Then edit the ``input.json`` according to corresponding documentions.

Finally, run the workflow::

    $ java -Dsystem.job-shell=/bin/sh -Dconfig.file=/path/to/Hi-C_Assembly_pipeline/docker/localhost.normal-user.docker.config -jar /path/to/cromwell-42.jar run /path/to/this_workflow -i input.json -p /path/to/Hi-C_Assembly_pipeline/src.zip

.. warning::

    The ``-p /path/to/Hi-C_Assembly_pipeline/src.zip`` option is very important.
    Cromwell will find the dependencies from this zip file for the workflow you are running.

.. tip::
    A ``Main*-workflow`` is the most frequently used pipeline, which invokes
    many ``sub-workflow``.

    A ``sub-workflow`` is useful when you want part of the functions
    (e.g. translate CDS sequences into proteins) provided
    by this module.


About the cromwell config file
================================

1. ``/path/to/Hi-C_Assembly_pipeline/docker/localhost.normal-user.docker.config`` will run all tasks in your localhost with a non-root user identity.

2. ``/path/to/Hi-C_Assembly_pipeline/docker/localhost.root.docker.config`` will run all tasks in your localhost with root user identity.

3. ``/path/to/Hi-C_Assembly_pipeline/docker/sge.root.docker.config`` will run all task as a root user in a SGE cluster. However, I have not tested it. And you must edit this file on where the docker images can be found!!



