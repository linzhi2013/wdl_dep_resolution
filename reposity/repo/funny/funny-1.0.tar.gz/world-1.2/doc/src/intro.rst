============================================================
Introduction
============================================================



Goals
========

Rewrite the HiC-pro pipeline with WDL.



Currently, only the ``01_QC`` and ``02_MAP`` are rewritten with WDL,
to generate a Hi-C QC report.


