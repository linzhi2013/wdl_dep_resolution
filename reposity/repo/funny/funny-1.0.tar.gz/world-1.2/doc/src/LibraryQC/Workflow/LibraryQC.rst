=========================================================
Main-workflow: Hi-C Library Quality Control Pipeline
=========================================================



LibraryQC
=========================

The main workflow for Hi-C library QC.


`Input`:
    :fq1 (`File`):
        Input ``read1.fastq(.gz)`` file.

    :fq2 (`File`):
        Input ``read2.fastq(.gz)`` file.

    :genome_fasta_file (`File`):
        Input genome file in Fasta format.

    :species_name (`String`):
        Species name.

        Default: ``fungi``.

    :job_thread (`Int`):
        Split each Fastq file into # sub-fastq files,
        then all sub-fastq files will be run simultaineously.
        For example, if ``job_thread==4``, then there will be
        8 tasks (e.g. Bowtie2 mapping) at the same time.

        Default: ``4``.

        .. warning::
            Except there will be ``job_thread*2`` tasks at the
            same time, in many case, each task is also a multiple-thread command
            (e.g. the bowtie2 command support mutiple-threads).
            Thus, do not let the total thread number be larger than
            the computer resources avaiable to you!

    :fastp_other_para (`String`):
        Other Fastp parameters.

        Default: empty string.

    :fastp_thread (`String`):
        Thread number for Fastp.

        Default: ``4``.

    :fastp_mem_size (`String`):
        Fastp Memory size.

        Default: ``16G``.

    :samtools_faidx_other_para (`String`):
        Other Samtools faidx parameters.

        Default: empty string.

    :faidx_mem_size (`String`):
        Samtools faidx Memory size.

        Default: ``16G``.

    :restriction_sites (`String`):

        Restriction sites

        Default: ``dpnii``.

    :bt2_index_base (`String`):
        The bowtie2 database name prefix.

        Default: ``bt2_ref_db``.

    :bowtie2_build_other_para (`File`):
        Other Bowtie2 parameters.

        Default: empty string.

    :bowtie2_build_thread (`Int`):
        Thread number for Bowtie2-build.

        Default: ``4``.

    :bowtie2_build_mem_size (`String`):
        Bowtie2 build memory size.

        Default: ``16G``.

    :phred64 (`Boolean`):
        Is the quality input Fastq file based on phred64?

        Values can be ``false``, ``true``.

        Default: ``false``.

    :bowtie2_map1_other_para (`String`):
        Default: ``--no-sq --very-sensitive -L 30 --score-min L,-0.6,-0.2 --end-to-end --reorder --rg-id BMG``.

    :bowtie2_map2_other_para (`String`):
        Default: ``--no-sq --very-sensitive -L 20 --score-min L,-0.6,-0.2 --end-to-end --reorder --rg-id BML``.

    :bowtie2_map_thread (`Int`):
        Bowtie2 mapping thread number.

        Default: ``4``.

    :bowtie2_map_mem_size (`String`):
        Bowtie2 mapping memory size.

        Default: ``16G``.

    :cutsite (`String`):
        For cutsite-trimming.

        Default: ``GATCGATC``.

    :samtools_merge_other_para (`String`):
        Other parameters for samtools merege.

        Default: ``-n -f``.

    :samtools_merge_thread (`Int`):
        Thread number for samtools merge.

        Default: ``4``.

    :samtools_merge_mem_size (`String`):
        Memory size for samtools merge.

        Default: ``16G``.

    :samtools_sort_other_para (`String`):
        Other parameters for samtools sort.

        Default: ``-n``.

    :samtools_sort_thread (`Int`):
        Thread number for samtools sort.

        Default: ``4``.

    :samtools_sort_mem_size (`String`):
        Memory size for samtools sort
        Default: ``16G``.

    :min_map_qual (`String`):
        Default: ``0``.

    :mergeSAM_other_para (`String`):
        Default: ``-t -v``.

    :mergeSAM_mem_size (`String`):

        Default: ``16G``.

    :mapped_2hic_fragments_other_para (`String`):
        Other parameters for mapped_2hic_fragments.py.

        Default: ``-v -S -t 100 -m 100000000 -s 100 -l 700 -a``.

    :lib_info_xls (`File`):
        Library information, content format::

            Index    限制性内切酶  酶切位点    下机数据量（G）
            GTCCGC  DpnII   GATC    14.535
            GTCCGC  DpnII   GATC    137.948


    :report_dir (`String`):
        The Hi-C QC report directory name.

    :contract_number (`String`):
        Phone number.

    :project_name (`String`):
        Project name.

    :writer (`String`):
        Who prepare this Hi-C QC report?

    :reviewer (`String`):
        Who double-check this Hi-C QC report?

    :workdir_base (`String`):
        The working directory. All output files will be written to this directory.

    :root (`String`):
        The root direcotry for mounting (``-v ${root}:${root}`` when run docker).
        This parameter must be provided if you run the task with Docker.

        Default: ``/export/``.

`Output`:
    The Hi-C QC report file will be in the ``03_HiC_QC_report`` directory under ``workdir_base``.




