======================
Credits
======================


Original Pipeline
======================

https://github.com/nservant/HiC-Pro


Custom version for NextOmics
=============================

Langchao cluster: ``/export/personal1/duanxk/script/process_lachesis/Lachesis_pipeline_v2``.


LibraryQC module
====================

Written with WDL.

**Workflow design and implementation (Coding, testing and documention writing)**:

Guanliang Meng

**Test data and many pipeline instrudction and other help from**:

Xiaoke Duan.


**Assistance during Huawei Cloud testing**

Lingxia He (IT department)



