.. Hi-C Assembly Pipeline documentation master file, created by
   sphinx-quickstart on Tue Oct 22 13:02:37 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Hi-C Assembly Pipeline's documentation!
==================================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:
   :numbered:

   src/intro
   src/INSTALL

   src/LibraryQC/index

   src/credits
   src/history

   src/Copyright
