.. Hi-C Assembly Pipeline documentation master file, created by
   sphinx-quickstart on Tue Oct 22 13:02:37 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

LibraryQC
==================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   framework

   Workflow/LibraryQC_QuickStart

   Workflow/LibraryQC_QuickStart_HuaweiCloud

   Workflow/LibraryQC
