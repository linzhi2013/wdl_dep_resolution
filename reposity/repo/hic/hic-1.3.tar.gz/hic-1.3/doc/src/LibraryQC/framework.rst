============================================================
The Architecture of LibraryQC Module
============================================================

For the ``LibraryQC`` module:

.. image:: ../img/LibraryQC.png


